<?php
function __autoload($classname) {
    $filename =  $classname .".php";
    include_once($filename);
}
$db = ORM::getInstance();
$db->setTable('product');
$flag=$_GET['flag'];
if($flag==1){//add product
	$rules = array(
		'product_name'=>'required',
		'price'=>'required',
		'category'=>'required',
	);


/////////////image validation/////////////////////////
if ($_POST){
		$upfile = "./images/productimage/".$_FILES['image']['name'] ;
		$image_name=$_FILES['image']['name'];
		$image_path="./images/productimage/".$image_name;
		$image_error="";
		if ($_FILES['image']['error'] > 0)
		{
			switch ($_FILES['image']['error'])
			{
			case 1: $image_error='* Image exceeded upload_max_filesize';
			break;
			case 2: $image_error='* Image exceeded max_file_size';
			break;
			case 3: $image_error='* Image only partially uploaded';
			break;
			case 4:
			if($_POST['image']!=""){
			$image_name=$_POST['image']; 
			    }else{
					
					$image_error='* No image uploaded';
				}
			break;
			case 6: $image_error='* Cannot upload image: No temp directory specified';
			break;
			case 7: $image_error='* Upload failed: Cannot write to disk';
			break;
			}
			
		}
		else{
			if ($_FILES['image']['type']!='image/png')
			{
				$image_error='* image is not png';
				
			}
			if (is_uploaded_file($_FILES['image']['tmp_name']))
			{
				if (!move_uploaded_file($_FILES['image']['tmp_name'], $upfile))
				{
					$image_error='* Could not move image to destination directory';
				}else{
					if($_FILES['image']){
						$image_name=$_FILES['image']['name'];
					 }elseif($_POST['image']){
						$image_name=$_POST['image']; 
					 }else{$image_error='* No image uploaded';}
				  }
			}
			else
			{
					if($_FILES['image']){
						$image_name=$_FILES['image']['name'];
					 }elseif($_POST['image']){
						$image_name=$_POST['image']; 
					 }else{$image_error='* No image uploaded';}

				
			}
		}

}

////////validation/////////////////////////

		$validation=new Validation();
		if($validation->validate($_POST,$rules)==true&&$image_error=="")  //check validation 
		{		
				$db->setTable('category');
				$cat_id=$db->select('cat_id',array('cat_name'=>$_POST['category']));
				$db->setTable('product');
				if($_POST['up']=="0"){//insert product
					$mysqli = $db->select('product_name',array('product_name'=>$_POST['product_name']));
					if(count($mysqli)!=0){//if product already exist
						$msg="This Product is already exist";
						header("Location: ./addproduct.php?".http_build_query($_POST)."&msg=$msg");
					}else{//if it was new product
						if(!is_numeric($_POST['price'])){//if price was number or not
							$msg="Price has to be a Number";
							header("Location: ./addproduct.php?".http_build_query($_POST)."&msg=$msg");
						}else{
							$mysqli = $db->insert(array('product_name'=>$_POST['product_name'],
							'price'=>$_POST['price'],'cat_id'=>$cat_id,
							'status'=>'available','product_picture'=>$image_name));
							$msg="This Product has been add";
							
							
							header("Location: ./addproduct.php?msg=$msg");
						}
					}	
				}else{//update product
					//frist i have to find if the updated name in table or not 
					//1) i selected the current name 
					$previous_name=$db->select('product_name',array('product_id'=>(int)$_POST['up']));
					//2) i selected all names 
					$mysqli = $db->select(array('product_name'),"");
					$names=explode(",",$mysqli);
					//3) i remove the current name from array in case user wouldn't update name
					$diff=array_diff( $names, [$previous_name] ); 
					//4)search if the new name in the table
					if (in_array($_POST['product_name'], $diff)) {//if product already exist
						$msg="This Product is already exist";
						header("Location: ./addproduct.php?".http_build_query($_POST)."&msg=$msg");
					}else{//if product not exit 
						if(!is_numeric($_POST['price'])){//if price was number or not
							$msg="Price has to be a Number";
							header("Location: ./addproduct.php?".http_build_query($_POST)."&msg=$msg");
						}else{
							$mysqli = $db->update(array('product_name'=>$_POST['product_name'],
							'price'=>$_POST['price'],'cat_id'=>$cat_id,'product_picture'=>$image_name),array('product_id'=>(int)$_POST['up']));
							header("Location: ./allproducts.php");
					    }	
					}
				}	
				
				
		}else{  // if data not valid
		
			$err=$validation->errors; 
			$error="";
			$i=0;//must be here
				 for($i=0 ; $i<count($err) ; $i++){
					 $error=$error."&Err[$i]=".$err[$i]; 
				}
				if($image_error)
				{$error=$error."&imgErr=".$image_error;}
			header("Location: ./addproduct.php?".http_build_query($_POST)."&Err=$error");
		}
}elseif($flag==2){//delete product

	$db->setTable('product');
	$imgname=$db->select('product_picture',array('product_id'=>$_GET['id']));
	// unlink('images/productimage/'.trim($imgname));
	$mysqli = $db->update(array('status'=>'unavailable'),array('product_id'=>$_GET['id']));

	// $mysqli = $db->delete(array('product_id'=>$_GET['id']));

	header("Location: ./allproducts.php");

}elseif($flag==3){//available or unavailabe

	$db->setTable('product');
		if($_GET['val']=='available')
			{
				$status='unavailable';
			}else{
				$status='available';
			}
	$mysqli = $db->update(array('status'=>$status),array('product_id'=>$_GET['id']));
	echo "<input type='hidden' id='product_status' value='/project/allproducts.php'>";
	// header("Location: ./allproducts.php");

}elseif($flag==4){//update product
	$db->setTable('product');

		$product=$db->select("*",array('product_id'=>$_GET['id']));
		$cat_id=$product->{'cat_id'};
		$id=$_GET['id'];
		$product_name=$product->{'product_name'};
		$price=$product->{'price'};
		$image=$product->{'product_picture'};
		$db->setTable('category');
		$cat_name=$db->select('cat_name',array('cat_id'=>$cat_id));
		header("Location: ./addproduct.php?product_name=$product_name&price=$price&image=$image&category=$cat_name&up=$id");
			

}
?>
<script>
var exampleSocket = new WebSocket("ws://localhost:8080");
exampleSocket.onopen = function (event) {
var message = {
cmd:"availablility"
};
exampleSocket.send(JSON.stringify(message)); 
var product_status=document.querySelector('#product_status');
window.location.assign(product_status.value);
}
</script>
