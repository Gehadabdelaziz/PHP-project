<?php require_once('admin_bar.php');
session_start();
if(isset($_SESSION["id"]))
{
	if ($_SESSION['id']==1) {	
	echo "<div class='col-md-offset-9 col-md-4'>";
	$userimage=$_SESSION["pic"];
	echo "<img src='images/userimage/$userimage' width='80' height='80'/>";
	echo "admin ".$_SESSION["name"];
	echo "</div>";
	echo "<div class='col-md-offset-10 col-md-4'>";
	echo "<a href=logout.php >logout</a>";
	echo "</div>";
	}
	else
	{
		echo '<h1 class="text-center" style="margin-top:200px"><font color="#990000">
		Permission Denied</font></h1>';
	
		exit();
	}

}
else
{ 
header("Location: /project/log.php");	
} 
?>
<!DOCTYPE html>

<html>
<body onload="order_ajax()">
	<div class="container">
	<div class="row">
	<div id="div1" class="col-md-offset-3 col-md-6">
	<strong>Orders</strong>
<script>
	function order_ajax () {
	    if(window.XMLHttpRequest) {
		ajaxRequest = new XMLHttpRequest();
	    }
	    else {
		ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
	    }
	    ajaxRequest.open("GET" , "./order_ajax.php", true);
	    ajaxRequest.send();


	
	ajaxRequest.onreadystatechange = function(){
	    if (ajaxRequest.readyState === 4 && ajaxRequest.status === 200) {
		   var response = JSON.parse(ajaxRequest.responseText);
		   console.log(response);
			numOptions = response.length;
			for (i = 0; i < numOptions; i++) {
				var order_id=response[i].order_id;
				var div=document.createElement('div');
				div.setAttribute("class","table-responsive");
			    var table = document.createElement('table');
			    table.setAttribute("class", "table table-bordered");
			    table.setAttribute("id",response[i].order_id);
			    var tbody=document.createElement('tbody');
			    var tr = document.createElement('tr');
			    tr.setAttribute("class","info"); 
			    var td1=document.createElement('td');  
			    var td2=document.createElement('td');
			    var td3=document.createElement('td');
			    var td4=document.createElement('td');
			    var td5=document.createElement('td');
			    var text1 = document.createTextNode('Order Date');
			    var text2 = document.createTextNode('Name');
			    var text3 = document.createTextNode('Room');
			    var text4 = document.createTextNode('Ext.');
			    var text5 = document.createTextNode('Action');
			    td1.appendChild(text1);
			    td2.appendChild(text2);
			    td3.appendChild(text3);
			    td4.appendChild(text4);
			    td5.appendChild(text5);
			    tr.appendChild(td1);
			    tr.appendChild(td2);
			    tr.appendChild(td3);
			    tr.appendChild(td4);
			    tr.appendChild(td5);
			    tbody.appendChild(tr);
			    var tr2=document.createElement('tr');
			    for (var j = 0; j < 5; j++) {
			    	switch (j){
				    	case 0:
				    	var td0=document.createElement('td');
				    	var text=document.createTextNode(response[i].order_date);
				    	td0.appendChild(text);
				    	tr2.appendChild(td0);
				    	break;
				    	case 1:
				    	var td1=document.createElement('td');
				    	var text=document.createTextNode(response[i].user_name);
				    	td1.appendChild(text);
				    	tr2.appendChild(td1);
				    	break;
				    	case 2:
				    	var td2=document.createElement('td');
				    	var text=document.createTextNode(response[i].user_room);
				    	td2.appendChild(text);
				    	tr2.appendChild(td2);
				    	break;				    	
				    	case 3:
				    	var td3=document.createElement('td');
				    	var text=document.createTextNode(response[i].user_ext);
				    	td3.appendChild(text);
				    	tr2.appendChild(td3);
				    	break;
				    	case 4:	
				    	var td4=document.createElement('td');
				    	var deliver = document.createElement('input');
    					deliver.setAttribute('type', 'button');
    					deliver.setAttribute('value','Deliver');
    					deliver.setAttribute('class','btn btn-link');
    					deliver.setAttribute('id',order_id);
    					deliver.onclick = function(){update_order(this)}; 
				    	td4.appendChild(deliver);
				    	tr2.appendChild(td4);

				    	break;	    		
			    	}
			    	
			    	
			    };

				    //view pic	
				   var tr3=document.createElement('tr');
				   var td6=document.createElement('td');
				   td6.setAttribute("colspan", "5");
				   var pic = (response[i].order_pic).split(",");
				   var amount = (response[i].order_amount).split(",");
				   var product_name = (response[i].order_name).split(","); 	 
				   numpic = pic.length;
				   for (x = 0; x < numpic; x++) {
					var div2 = document.createElement("div");
					div2.style.border = "thin solid";
					div2.style.margin = "5px 5px 5px 5px";
					var header = document.createElement("p");
					var headtext=document.createTextNode(product_name[x]+" : "+amount[x]);
					var elem = document.createElement("img");
	 				elem.src = "/project/images/productimage/"+pic[x];
					elem.setAttribute("height", "100");
				    	elem.setAttribute("width", "100");
	    				div2.style.cssFloat = 'left';
					div2.appendChild(header);
					div2.appendChild(elem);
					header.appendChild(headtext);
					td6.appendChild(div2);

					}
				   var div3 = document.createElement("div");
				   var div4 = document.createElement("div");
				   var div5 = document.createElement("div");	
				   div3.style.textAlign = "right";			
				   var para = document.createElement("p");
	 			  //div3.style.position = "relative";
					//para.style.position = "fixed";
				  // div3.stylestyle.verticalAlign ;
				   div5.style.verticalAlign="bottom";
				   //para.style.textAlign = "right";
				  
				   var node = document.createTextNode("Total ="+response[i].order_price);
				 	
				   para.appendChild(node);
				   div5.appendChild(para);
				   div3.appendChild(div4);
				   div3.appendChild(div5);		
				   td6.appendChild(div3);
				   tr3.appendChild(td6);

			    tbody.appendChild(tr2);
			    tbody.appendChild(tr3);//end pic
			    table.appendChild(tbody);
			    div.appendChild(table);
			    document.getElementById("div1").appendChild(div);

			}
			

	    }
	};
	}

	var exampleSocket = new WebSocket("ws://127.0.0.1:8080");

    exampleSocket.onopen = function (event) {
     // exampleSocket.send("Here's some text that the server is urgently awaiting!"); 
    }

    exampleSocket.onmessage = function (event) 
    {
        message = JSON.parse(event.data);
        //alert(event.data);
        if(message.cmd=="cancel" || message.cmd=="order")
        {
            load_again();
        }
    }


	function update_order(value)
	{
			var message = {
                cmd:"deliver"
                ,
                id:value.id
            };
            exampleSocket.send(JSON.stringify(message));

		
			console.log(value.id);
		    if(window.XMLHttpRequest) {
			ajaxRequest = new XMLHttpRequest();
		    }
		    else {
			ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
		    }
		    ajaxRequest.open("GET" , "./update_order.php?order_id="+value.id, true);
		    ajaxRequest.send();

		    ajaxRequest.onreadystatechange = function(){
		     if (ajaxRequest.readyState === 4 && ajaxRequest.status === 200) {
		     	if (ajaxRequest.responseText=='done') {
		     	 load_again();
		     	};

		     }
		 }
		 
	}

	function load_again(){ //call it when using websocket
		var tables=document.querySelectorAll(".table-bordered");
	 	 for (var i = 0; i < tables.length; i++) {
	 	 	var delete_table=tables[i].parentNode;
	 	 	delete_table.removeChild(tables[i]);
	 	 };
		 order_ajax();
	}

</script>
</div></div></div>	
</body>
</html>