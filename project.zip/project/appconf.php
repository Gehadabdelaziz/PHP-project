<?php
$GLOBALS['conf'] = array(
    'host'=>'localhost',
    'username'=>'root',
    'password' =>'root', 
    'db_name'=>'cafe_system'   
);



