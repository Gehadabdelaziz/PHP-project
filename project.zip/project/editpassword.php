<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href= "/project/bootstrap-3.3.2-dist/css/bootstrap.css">
	<link rel="stylesheet" href= "/project/bootstrap-3.3.2-dist/css/bootstrap-theme.css">
	<script src="/project/jquery-2.1.3.min.js" type="text/javascript"></script>
	<script src="/project/bootstrap-3.3.2-dist/js/bootstrap.js" type="text/javascript"></script>
</head>

<body>	
	<div class="container">
	<div class="row">
	<div class="col-md-offset-4 col-md-3">
<form  class="form-signin" action="./login_validation.php/?flag=3"  method="POST" style="margin-top:180px">

<div class="form-group">
<label>Please Edit Password</label><br>
<input class="form-control" type="password" name="password" placeholder='Enter Your password ...'/>
</div>

<div class="form-group">
<label>Confirm Password</label><br>
<input class="form-control" type="password" name="confirm_password" placeholder='re-Enter Your password ...'/>
</div>
<input class="btn btn-primary btn-sm" type="Submit" name="Submit" value="Submit"><br><br>
</form>
<?php if(!empty($_GET['Err'])) {foreach($_GET['Err'] as $e ){echo  $e."<br>";}}?>

	</div>
	</div>
	</div>
	</body>
</html>
