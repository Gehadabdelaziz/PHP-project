<?php 
session_start();
if(isset($_SESSION["id"]))
{
		if($_SESSION['id']==1)
		   {
			header("Location: /project/homeadmin.php");
		    }
		    else
		    {
			header("Location: /project/process.php");	
		  }	
}else{	

?>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href= "/project/bootstrap-3.3.2-dist/css/bootstrap.css">
	<link rel="stylesheet" href= "/project/bootstrap-3.3.2-dist/css/bootstrap-theme.css">
	<script src="/project/jquery-2.1.3.min.js" type="text/javascript"></script>
	<script src="/project/bootstrap-3.3.2-dist/js/bootstrap.js" type="text/javascript"></script>
</head>
<body >	
	<div class="container">
	<div class="row">
	<div class="col-md-offset-4 col-md-3">

	
<div id="form">
<form class="form-signin" action="login_validation.php/?flag=0" method="POST" style="margin-top:180px">
<div class="col-md-3"></div>
<strong><font size="5">Cafeteria</font></strong><br>

<div class="form-group">
<label>Email</label><br>
<input class="form-control" type="text" name="mail" placeholder='Enter Your email ...'/>
</div>

<div class="form-group">
<label>Password</label><br>
<input class="form-control" type="password" name="password" placeholder='Enter Your password ...'/>
<br>
<input class="btn btn-primary btn-sm" type="submit" name="submit" value="Login">
<br><br>
<a href="forgetpassword.php/?ques=no_ques">Forget Password</a><br><br>

<?php if(!empty($_GET['Err'])) {foreach($_GET['Err'] as $e ){echo  $e."<br>";}}?>
</form>
</div>
<?php }?>

</body>


</html>
