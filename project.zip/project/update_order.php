<?php 

header('Content-Type: application/json');

function __autoload($classname) {
    $filename =  $classname .".php";
    include_once($filename);
}


$obj = ORM::getInstance();
if (!empty($_GET)){
	$order_id=$_GET['order_id'];
	$obj->setTable('orders');
	$updated=$obj->update(array('order_status'=>'out for delivery'),array('order_id'=>$order_id));
	if ($updated) {
		$order_updated="done";
		echo ($order_updated);
	}
	else
	{
		$order_updated="Error in update";
		echo ($order_updated);
	}
	
}
?>
