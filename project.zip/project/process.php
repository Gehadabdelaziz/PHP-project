<?php
require('user_bar.php');
session_start();
if(isset($_SESSION["id"]))
{
    echo "<div class='col-md-offset-9 col-md-4'>";
    $user_id=$_SESSION["id"];
    $userimage=$_SESSION["pic"];
    echo "<img src='images/userimage/$userimage' width='80' height='80'/>";
    echo "user ".$_SESSION["name"];
    echo "</div>";
    echo "<div class='col-md-offset-10 col-md-4'>";
    echo "<a href=logout.php >logout</a>";
    echo "</div>";

}
else
{ 
header("Location: ./log.php");  
} 


?>

<!DOCTYPE html>
<html>
<head>
<?php
    //exec
    //system('php bin/chat-server.php &');
?> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  
    <style>
        html, body {
            height: 100%;
            margin: 0;
        }
        .wrapper {
            display: table;
            height: 100%;
            width: 100%;
            min-width: 688px;
            background-color: #FFFFFF;
              /* just to make sure nothing bleeds background: grey;*/
        }
        .list{
            
           
            background-color: #FFFFFF;
            height: 400px;
            
            overflow: scroll;

        }
        .order{
            
            width: 35%;
            min-width: 235px;
            background-color: #FFFFC0;
            float: left;
            

        }
        .page{
            
            float: right;
            display: table-row;  /* height is dynamic, and will expand... */
            width: 64%;
            height: 100%;
            background-color: #FFFFFF;
                    /* ...as content is added (won't scroll) */
                   /* ...as content is added (won't scroll) */
                    
            
            

        }
        .product{
            
           
            background-color: #FFFFFF;
           /* padding: 0; */

        }
    </style>
   
</head>
<body onload="loadRooms();">



<div class="wrapper"> 
<div class="well order">
            <div class=" well list">
                
                    

                     

                    

                    
                    

                     

                   
                    

                   
               
            </div>

            <div class="form-group">
              <label for="room">Room :</label>
              <select class="form-control" id="room">
                <option>100</option>
                
                
              </select>
            </div>
    <div class="form-group">
      <label for="notes">Notes:</label>

      <textarea class="form-control" rows="5" id="notes"></textarea>
    </div>
    <button type="button" onclick="sendOrder()" class="btn btn-info btn-lg">SUBMIT</button>        
    <font size='6'><span id='total-amount' class='label label-default total' style="float:right;padding:15px;">EGP 0</span> </font>

</div> 


<div class=" well page">
    <div class="well">
            <div class="row">
                <div class="col-xs-5">
                   
                </div>
                <div class="col-xs-7">
                    
                    <div class="input-group">
                      <input type="text" class="form-control" onkeyup="searchProducts(this)" placeholder="Search" aria-describedby="basic-addon2">
                      <span class="input-group-addon" id="basic-addon2" > <span class="glyphicon glyphicon-search"></span>
                    </div>
                </div>
                
            </div>   
        </div>
        
        


                <div class='col-xs-6 col-lg-4 onlist'  onclick='' style='cursor: pointer;'>
                    <div class='well  product'>
                        <h3>Coffee</h3>
                        <img src='http://icons.iconarchive.com/icons/cute-little-factory/breakfast/256/coffee-cup-icon.png' width='100%' height='300px'>
                    </div>
                </div>

                


            
                
                
                
             
        
       
        
        

</div>    





</div>
    
    <div id="result"></div>
        </div>

    
 <script>

     
        var ajaxRequest1;
        var ajaxRequest2;
        var ajaxRequest3;
        var allProducts;
        var allRooms=[];
        var theTotal;
        var orderList=[];

        function searchProducts(field)
        {
        available = document.querySelectorAll(".onlist");
        var key = field.value.trim();
        for(i=0;i<available.length;i++)
        {
            available[i].style.display = "block";
        }
        if(key.length == 0 )return ;
        for(i=0;i<available.length;i++)
        {
            match = false ;
            tokens = allProducts[i].product_name.toLowerCase()+" "+allProducts[i].category_name.toLowerCase();
            tokens = tokens.split(" ");
            for(j=0;j<tokens.length;j++)
            {
                if(tokens[j].substr(0, key.length) == key)
                {
                match = true ;
                }
            }
            if(match == false)
            {
                available[i].style.display = "none";
            }
    }
}
        function loadProducts() {
            if(window.XMLHttpRequest) {
                ajaxRequest1 = new XMLHttpRequest();
            }
            else {
                ajaxRequest1 = new ActiveXObject("Microsoft.XMLHTTP");
            }
            ajaxRequest1.open("GET" , "/project/display.php", true);
            //ajaxRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            //xmlhttp.setRequestHeader("X-CSRFToken",'dMTISkUIa4DOT7M3zM2SKpuYlHAtDnYo');
            
            ajaxRequest1.send();
        


        ajaxRequest1.onreadystatechange = function(){
            if (ajaxRequest1.readyState === 4 && ajaxRequest1.status === 200) {
                allProducts = JSON.parse(ajaxRequest1.responseText);
                draw();loadRooms();
            }
        };

        }

        function add(id)
        {
            var toBeAdded = {x:1};
            list = document.querySelector(".list");
            var selected;
            for(i=0;i<allProducts.length;i++)
            {
                if(allProducts[i].product_id==id){selected=allProducts[i];break;}
            }
            items = document.querySelectorAll(".list-item");
            for(i=0;i<items.length;i++){
                if(items[i].id==id){
                    alert("already there");
                    return;
                }
            }
            toBeAdded.product_id = selected.product_id;
            toBeAdded.product_name = selected.product_name;
            toBeAdded.price = selected.price;
            toBeAdded.product_name = selected.product_name;
            toBeAdded.quantitiy = 1;
            
            orderList.push(toBeAdded);
            //alert(toBeAdded.product_name);
            quant = toBeAdded.quantitiy+":"+toBeAdded.product_name
            total = "EGP "+toBeAdded.price;
            //list.innerHTML = "";
            list.innerHTML +="<div id='"+toBeAdded.product_id+"' class='well list-item'><div class='row'><div class='col-lg-4'><h3 class='quant'>"+quant+"</h3></div>"+
            "<div class='col-lg-2'><button type='button'  class='up btn btn-success btn-xs btn-block'><span class='glyphicon glyphicon-plus'></button><button type='button'  class='down btn btn-danger btn-xs btn-block'><span class='glyphicon glyphicon-minus'></button></div>"+
"<div class='col-lg-2'><font size='5'><span class='label label-default total' >"+total+"</span> </font></div><div class='col-lg-2'></div><div class='col-lg-1'><button type='button' onclick='rm("+toBeAdded.product_id+",this.parentNode.parentNode.parentNode)' class='btn btn-danger btn-ms '><span class='glyphicon glyphicon-remove'></button></div></div></div>";
            arr = document.querySelectorAll(".up");
            for (i=0 ; i < arr.length ; i++)
            {
                arr[i].onclick = function(e){
                    parent = e.target.parentNode.parentNode.parentNode;
                    id = (parent.id);
                    
                    //return;
                    ar2 = document.querySelectorAll(".up");
                    //index = 0 ;
                    //for(i=0;i<ar2.length;i++)
                    //{
                    //    if(e.target==ar2[i]){index=i;break;}
                    //}
                    //alert(index);
                    var selected;//=orderList[index];
                    for(i=0;i<orderList.length;i++)
                    {
                        if(orderList[i].product_id==id){selected=orderList[i];break;}
                    }
                    selected.quantitiy+=1;
                    parent.querySelector(".quant").innerHTML = selected.quantitiy+":"+selected.product_name;
                    parent.querySelector(".total").innerHTML = "EGP "+(selected.quantitiy*selected.price);
                    calculateTotal();
                }
            }
            arr = document.querySelectorAll(".down");
            for (i=0 ; i < arr.length ; i++)
            {
                arr[i].onclick = function(e){
                    parent = e.target.parentNode.parentNode.parentNode;
                    console.log(parent.id);
                    var selected=orderList[0];
                    for(i=0;i<orderList.length;i++)
                    {
                        if(orderList[i].product_id==parent.id){selected=orderList[i];break;}
                    }
                    if(selected.quantitiy>1)
                    {
                        selected.quantitiy-=1;
                        parent.querySelector(".quant").innerHTML = selected.quantitiy+":"+selected.product_name;
                        parent.querySelector(".total").innerHTML = "EGP "+(selected.quantitiy*selected.price);
                        calculateTotal();
                    }
                }
            }

            calculateTotal();
        }

        function draw(){
            items  = document.querySelectorAll(".onlist");
            
            for(i=0;i<items.length;i++)
            {
               var aux = items[i].parentNode;
              aux.removeChild(items[i]);
            }
            page  = document.querySelector(".page");
            
            for(i=0;allProducts.length;i++)
            {
                product = allProducts[i];
                page.innerHTML += "<div class='col-xs-6 col-lg-3 onlist'  onclick='add("+product.product_id+")' style='cursor: pointer;'><div class='well  product' style='height:275px;'><h3>"+product.product_name+"</h3><img src='/project/images/productimage/"+product.product_picture+"' width='100%' height='auto'></div></div>"

            }
        }

        function all()
        {
            alert(trying);
        }

        function filter(id,operation)
        {
            alert("wasal");
        }
    
        function rm(id,elem)
        {
            
            var selected;//=orderList[index];
            index = 0 ; 
            for(i=0;i<orderList.length;i++)
            {
                if(orderList[i].product_id==elem.id){index=i;selected=orderList[i];break;}
            }
            orderList.splice(index,1);
            elem.parentNode.removeChild(elem);
            calculateTotal(); 
        }

        function calculateTotal()
        {
            totalAmount = document.querySelector("#total-amount");
            number = 0.0;
            for(i=0;i<orderList.length;i++)
            {
                number += orderList[i].price*orderList[i].quantitiy;
            }
            totalAmount.innerHTML = "EGP "+number;
            theTotal = number;
        }


        var exampleSocket = new WebSocket("ws://localhost:8080");

        exampleSocket.onopen = function (event) {
         // exampleSocket.send("Here's some text that the server is urgently awaiting!"); 
        }

        exampleSocket.onmessage = function (event) {
            x = JSON.parse(event.data);

            if(x.cmd == "availablility" )
            {
            loadProducts();
            }

        }

       


        function sendOrder() {
            if(orderList.length==0){return;}
            var n = document.querySelector("#notes").value;
            var r = document.querySelector("#room").selectedIndex;
            var order = {
                cmd:"order"
                ,
                data:orderList
                ,
                notes:n
                ,
                room:allRooms[r].room_id
                ,
                user_id:<?php echo $user_id;?>
                ,
                total_price:theTotal
            };
            exampleSocket.send(JSON.stringify(order));
            orderList=[];
            document.querySelector(".list").innerHTML="";
            document.querySelector("#notes").value="";
            calculateTotal();
        }

        function loadRooms()
        {
            
            if(window.XMLHttpRequest) {
                ajaxRequest2 = new XMLHttpRequest();
            }
            else {
                ajaxRequest2 = new ActiveXObject("Microsoft.XMLHTTP");
            }
            ajaxRequest2.open("GET" , "/project/getdata.php?request=room", true);
            //ajaxRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            //xmlhttp.setRequestHeader("X-CSRFToken",'dMTISkUIa4DOT7M3zM2SKpuYlHAtDnYo');
            
            ajaxRequest2.send();
        


            ajaxRequest2.onreadystatechange = function(){
            if (ajaxRequest2.readyState === 4 && ajaxRequest2.status === 200) {

                allRooms = JSON.parse(ajaxRequest2.responseText);
                roomCheckBox = document.querySelector("#room");
                roomCheckBox.innerHTML = "";
                for(i=0;i<allRooms.length;i++)
                {
                    roomCheckBox.innerHTML += "<option>"+allRooms[i].room_no+"</option>";
                }
            }
        };

        }


        

    

    calculateTotal();
    loadProducts();

    </script>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

</body>