<!Doctype>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href= "/project/bootstrap-3.3.2-dist/css/bootstrap.css">
		<link rel="stylesheet" href= "/project/bootstrap-3.3.2-dist/css/bootstrap-theme.css">
		<script src="/project/jquery-2.1.3.min.js" type="text/javascript"></script>
		<script src="/project/bootstrap-3.3.2-dist/js/bootstrap.js" type="text/javascript"></script>
	</head>
	<body>
		<nav class="navbar navbar-default navbar-static-top">
			<div class="container-fluid">
				<div class="navbar-header"></div> 
					<div> 
						<ul class="nav navbar-nav">
							<li><a href="process.php">Home</a></li> 
							<li><a href="myorders.php">My orders</a></li> 
						</ul> 
					</div> 
			</div> 
		</nav>
		</body>
</html>
