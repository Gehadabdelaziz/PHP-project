<?php require_once('admin_bar.php');
session_start();
if(isset($_SESSION["id"]))
{
	if ($_SESSION['id']==1) {	
	echo "<div class='col-md-offset-9 col-md-4'>";
	$userimage=$_SESSION["pic"];
	echo "<img src='images/userimage/$userimage' width='80' height='80'/>";
	echo "admin ".$_SESSION["name"];
	echo "</div>";
	echo "<div class='col-md-offset-10 col-md-4'>";
	echo "<a href=logout.php >logout</a>";
	echo "</div>";
	}
	else
	{
		echo '<h1 class="text-center" style="margin-top:200px"><font color="#990000">
		Permission Denied</font></h1>';
	
		exit();
	}

}
else
{ 
header("Location: /project/log.php");	
} 
?>
<!DOCTYPE html>
<html>
	<body>
	<div class="container">
	<div class="row">
	<div class="col-md-offset-8 col-md-4">
		<a href='addproduct.php'>Add product</a>
	</div>
	<div class="col-md-offset-3 col-md-6">
	<strong>All Products</strong>
	<div class="table-responsive">
		<table class="table table-bordered">
		<tr class="info">
		<td>Product</td>
		<td>Price</td>
		<td>Image</td>
		<td>Action</td>
		</tr>
		<?php
		function __autoload($classname) {
			$filename =  $classname .".php";
	    		include_once($filename);
	    	}
		$obj = ORM::getInstance();
		$obj->setTable('product');

		$columns_selected=array('product_name','price','product_picture','status');
		$products_selected=$obj->select($columns_selected,"");
		if($products_selected){
			$products=explode(",", $products_selected);
			for ($i=0; $i <count($products) ; $i+=count($columns_selected)) { 
			echo "<tr>";
				for ($j=$i; $j <(count($columns_selected)+$i)-2; $j++) { 
					echo "<td>".$products[$j]."</td>";
					if($i==$j){$product_id=$obj->select('product_id',array('product_name'=>$products[$j]));}	
				}
				echo '<td><img style="width:30px;height=30px;" src="images/productimage/'.$products[$j].'"/></td>';
				echo  '<td><a href="product_validation.php?flag=3&id='.$product_id.'&val='.$products[$j+1].'">'.$products[$j+1].'</a>';
					
				echo  "	<a href='product_validation.php?flag=4&id=$product_id'>edit</a>
						<a href='product_validation.php?flag=2&id=$product_id'>delete</a></td>";
				echo "</tr>";
				$j+=1;
			}
		}else{
			echo "There is no Products";
			echo  "<br><a href='addproduct.php'>Add Product</a>";
		} 
		?>

		</table>
		</div>
		</div>
		</div>
		</div>
		</body>
		</html>
		
