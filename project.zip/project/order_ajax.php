<?php
header('Content-Type: application/json');

function __autoload($classname) {
    $filename =  $classname .".php";
    include_once($filename);
}


$obj = ORM::getInstance();



class order
{
	public $order_date,$user_name,$user_room,$user_ext,$order_status,$order_price,$order_id,$order_pic,$order_amount,$order_name;
	function __construct($order_date,$user_name,$user_room,$user_ext,$order_status,$order_price,$order_id,$order_pic,$order_amount,$order_name)
	{
		$this->order_date=$order_date;
		$this->user_name=$user_name;
		$this->user_room=$user_room;
		$this->user_ext=$user_ext;
		$this->order_status=$order_status;
		$this->order_price=$order_price;
		$this->order_id=$order_id;
		$this->order_pic=$order_pic;
		$this->order_amount=$order_amount;
		$this->order_name=$order_name;


	}
}



$obj->setTable('orders');
$all_orders=$obj->selectall(array('order_status'=>'processing'));
$orders=array();
$picture="";
$amount="";
$product_name="";
$pic=array();
$name=array();
$amoun=array();
while ($my_order = $all_orders->fetch_assoc()) {
	$obj->setTable('users');
	$user_id=$my_order['user_id'];
	$user=$obj->select("*",array('user_id'=>$user_id));
	$obj->setTable('room');
	$room_no=$obj->select('room_no',array('room_id'=>$my_order['room_id']));
	//arguments to constructor
	$order_id=$my_order['order_id'];
	$order_date=$my_order['date'];
	$order_price=$my_order['total_price'];
	$order_status=$my_order['order_status'];
	$user_name=$user->user_name;
	$user_ext=$user->ext;
	$user_room=$room_no;

	//get products pic
	$obj->setTable('order_product');
	$all_products=$obj->selectall(array('order_id'=>$my_order['order_id']));
	while ($my_product = $all_products->fetch_assoc()) {
		$obj->setTable('product');
		$pic[]=$obj->select('product_picture',array('product_id'=>$my_product['product_id']));	
		$amoun[]=$my_product['amount'];
		$name[]=$obj->select('product_name',array('product_id'=>$my_product['product_id']));	 
	}
	$product_name=implode(",",$name);	
	$picture=implode(",",$pic);
	$amount=implode(",",$amoun);
	//object from constructor
	$order  = new order($order_date,$user_name,$user_room,$user_ext,$order_status,$order_price,$order_id,$picture,$amount,$product_name);
	$picture="";
	$amount="";
	$pic=array();
	$amoun=array();
	$name=array();
	$orders[] = $order ;
}

echo  json_encode($orders);


?>
