<?php require_once('admin_bar.php');
session_start();
if(isset($_SESSION["id"]))
{
	if ($_SESSION['id']==1) {	
	echo "<div class='col-md-offset-9 col-md-4'>";
	$userimage=$_SESSION["pic"];
	echo "<img src='images/userimage/$userimage' width='80' height='80'/>";
	echo "admin ".$_SESSION["name"];
	echo "</div>";
	echo "<div class='col-md-offset-10 col-md-4'>";
	echo "<a href=logout.php >logout</a>";
	echo "</div>";
	}
	else
	{
		echo '<h1 class="text-center" style="margin-top:200px"><font color="#990000">
		Permission Denied</font></h1>';
	
		exit();
	}

}
else
{ 
header("Location: /project/log.php");	
} 
?>
<!DOCTYPE html>
<html>
	<body>
	<div class="container">
	<div class="row">
	<div class="col-md-offset-8 col-md-4">
		<a href='adduser.php'>Add user</a>
	</div>
	<div class="col-md-offset-3 col-md-6">
	<strong>All Users</strong>
	<div class="table-responsive">
		<table class="table table-bordered">
		<tr  class="info">
		<td>Name</td>
		<td>Room</td>
		<td>Image</td>
		<td>Ext.</td>
		<td>Action</td>
		</tr>
		<?php
		function __autoload($classname) {
			$filename =  $classname .".php";
	    	include_once($filename);
	    	}
		$obj = ORM::getInstance();
		$obj->setTable('users');
		$columns_selected=array('user_name','Room_id','profile_picture','ext','email');
		$users_selected=$obj->select($columns_selected,"");
		if ($users_selected!="") {
			$users=explode(",", $users_selected);
			//to get room_no instead of room_id
			$obj->setTable('room');
			for ($i=1; $i <count($users) ; $i+=count($columns_selected)) {
				$room_selected=$obj->select('room_no',array('room_id'=>$users[$i]));
				$users[$i]=$room_selected;
			}
			for ($i=0; $i <count($users) ; $i+=count($columns_selected)) { 
				echo "<tr>";
				for ($j=$i; $j <count($columns_selected)+$i-1; $j++) { 
					echo "<td>";
					if ($j==$i+2) {
						echo "<img src='images/userimage/$users[$j]' width='80' height='80'/>";
					}
					else
					{
					echo $users[$j];				
					}
					echo "</td>";
				}
				if ($i>0) {
					$edit=$users[$i+4];
					echo  "<td><a href='adduser.php?email_edit=$edit'>edit</a>
					<a href='allusers.php?id=$i'>delete</a></td>";
				}

				echo "</tr>";
			}
		}

		//delete user from table
		if (isset($_GET["id"])){

		$id=$_GET["id"];
		$email_selected_user=$users[$id+4];
		$obj->setTable('users');
		$obj->delete(array('email'=>$email_selected_user));
		unlink('./images/userimage/'.trim($users[$id+2]));
		header("Location: allusers.php");
		}

		// if (isset($_GET["email_edit"])) {
		// 	header("Location: adduser.php?email_edit=$edit");
		// }

	?>

		</table>
	</div>
	</div>
	</div>
	</div>
	</body>
</html>