<?php require_once('admin_bar.php');
session_start();
if(isset($_SESSION["id"]))
{
    if ($_SESSION['id']==1) {   
    echo "<div class='col-md-offset-9 col-md-4'>";
    $userimage=$_SESSION["pic"];
    echo "<img src='images/userimage/$userimage' width='80' height='80'/>";
    echo "admin ".$_SESSION["name"];
    echo "</div>";
    echo "<div class='col-md-offset-10 col-md-4'>";
    echo "<a href=logout.php >logout</a>";
    echo "</div>";
    }
    else
    {
        echo '<h1 class="text-center" style="margin-top:200px"><font color="#990000">
        Permission Denied</font></h1>';
    
        exit();
    }

}
else
{ 
header("Location: /project/log.php");   
} 
?>
<!DOCTYPE HTML>
<html>
  <head>
    <link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.2.2/css/bootstrap-combined.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" media="screen"
     href="css/bootstrap-datetimepicker.min.css">

     <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>



   

 <div class="well">
            
                <div class="col-xs-5">
                    <div class="input-group">
                      
                        <div  class="input-append date datetimepicker">
                            <label >From :</label>
                          <input type="text" id="datetimepicker1" readonly></input>
                          <span class="add-on">
                            <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
                          </span>
                        </div>


                    </div>
                   
                </div>

                <div class="col-xs-2">
                </div>

                <div class="col-xs-5">
                    <div class="input-group">
                      
                        <div  class="input-append date datetimepicker">
                            <label >To :</label>
                          <input id="datetimepicker2" type="text" readonly></input>
                          <span class="add-on">
                            <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
                          </span>
                        </div>


                    </div>
                   
                </div>

                <button type="button" id="load-button" bom="hop" onclick="loadChecks()" class="btn btn-info btn-lg">LOAD</button>
                
            
        </div>

<div id="display-data" class="well">
    
        <strong>Orders : </strong>
        <div class="table-responsive">
            <table id='display' class="table table-bordered">

                <tr class="info">
                    <td>User Name</td>
                    
                    <td>Total Amount</td>
                    
                </tr>

                
                

            </table>
        </div>
    
        <div id="multiorders" style="display:none;">
            <div class="table-responsive">   
                <table id='display2' class="table table-bordered">

                    <tr class="info">
                        <td>Order Date</td>
                        
                        <td>Amount</td>
                        
                    </tr>

                    <tr class='unit2'><td><button type='button' onclick='' class='btn btn-success btn-xs plus' >+</button>  2015-03-05 13:37:28</td><td>30 EGP</td></tr>

                </table>
            </div>
        </div>

        
       <div  class="well" id="multiproducts" style="display:none;">
            <div class="row" id="el-data">
                
                 
            </div>  
        </div>

</div>


    
    <script type="text/javascript"
     src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.8.3/jquery.min.js">
    </script> 
    <script type="text/javascript"
     src="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.2.2/js/bootstrap.min.js">
    </script>
    <script type="text/javascript"
     src="js/bootstrap-datetimepicker.min.js">
    </script>
    <script type="text/javascript"
     src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.pt-BR.js">
    </script>
    <script type="text/javascript">
      $('.datetimepicker').datetimepicker({
        format: 'yyyy-MM-dd hh:mm:ss',
        language: 'pt-BR'
      });
    </script>
    <script>
    
    var ajaxRequest1;
    var ajaxRequest2;
    var allChecks;
    var allOrders;
    var from;
    var to;


    

    function js_yyyy_mm_dd_hh_mm_ss () {
      now = new Date();
      year = "" + now.getFullYear();
      month = "" + (now.getMonth() + 1); if (month.length == 1) { month = "0" + month; }
      day = "" + now.getDate(); if (day.length == 1) { day = "0" + day; }
      hour = "" + now.getHours(); if (hour.length == 1) { hour = "0" + hour; }
      minute = "" + now.getMinutes(); if (minute.length == 1) { minute = "0" + minute; }
      second = "" + now.getSeconds(); if (second.length == 1) { second = "0" + second; }
      return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
    }

    function yesterday () {
      now = new Date();
      now.setDate(now.getDate()-1)
      year = "" + now.getFullYear();
      month = "" + (now.getMonth() + 1); if (month.length == 1) { month = "0" + month; }
      day = "" + now.getDate(); if (day.length == 1) { day = "0" + day; }
      hour = "" + now.getHours(); if (hour.length == 1) { hour = "0" + hour; }
      minute = "" + now.getMinutes(); if (minute.length == 1) { minute = "0" + minute; }
      second = "" + now.getSeconds(); if (second.length == 1) { second = "0" + second; }
      return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
    }

        document.querySelector('#datetimepicker1').value = yesterday ();

        document.querySelector('#datetimepicker2').value = js_yyyy_mm_dd_hh_mm_ss ();

    function loadChecks()
        {
            document.querySelector("#multiorders").style.display = "none";

            document.querySelector("#multiproducts").style.display = "none";
            
            if(window.XMLHttpRequest) {
                ajaxRequest2 = new XMLHttpRequest();
            }
            else {
                ajaxRequest2 = new ActiveXObject("Microsoft.XMLHTTP");
            }

            from = document.querySelector('#datetimepicker1').value.replace(/ /g, '+');

            to = document.querySelector('#datetimepicker2').value.replace(/ /g, '+');

            ajaxRequest2.open("GET" , "/project/getdata.php?request=check&from="+from+"&to="+to, true);
            //ajaxRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            //xmlhttp.setRequestHeader("X-CSRFToken",'dMTISkUIa4DOT7M3zM2SKpuYlHAtDnYo');
            
            ajaxRequest2.send();
        


            ajaxRequest2.onreadystatechange = function(){
            if (ajaxRequest2.readyState === 4 && ajaxRequest2.status === 200) {

                allChecks=JSON.parse(ajaxRequest2.responseText);

                

                items  = document.querySelectorAll(".unit");
            
                for(i=0;i<items.length;i++)
                {
                   var aux = items[i].parentNode;
                  aux.removeChild(items[i]);
                }

                
                display  = document.querySelector("#display");



                for(i=0;allChecks.length;i++)
                {

                    

                    display.innerHTML += "<tr class='unit'><td><button type='button' onclick='checkOrders("+allChecks[i].user_id+",this)' class='btn btn-success btn-xs plus' >+</button> "+allChecks[i].user_name+"</td><td>"+allChecks[i].total_price+" EGP</td></tr>";
                }

                
            }
        };

        }



        function checkOrders(id,button)
        {



            if(button.innerHTML=='+')
            {

                dashes = document.querySelectorAll('.dash');
                for(i=0;i<dashes.length;i++)
                {
                    dashes[i].innerHTML = '+';
                    dashes[i].className = 'btn btn-success btn-xs plus';
                }

                document.querySelector("#multiorders").style.display = "block";
                document.querySelector("#multiproducts").style.display = "none";
                //alert("sa7");
                button.innerHTML='-';
                button.className = 'btn btn-danger btn-xs dash';
                flag = 0;
            }
            else
            {
                button.innerHTML='+';
                button.className = 'btn btn-success btn-xs plus';
                document.querySelector("#multiorders").style.display = "none";
                document.querySelector("#multiproducts").style.display = "none";
                //disp.innerHTML ="";

                return;
            }



            
            if(window.XMLHttpRequest) {
                ajaxRequest1 = new XMLHttpRequest();
            }
            else {
                ajaxRequest1 = new ActiveXObject("Microsoft.XMLHTTP");
            }

      


            ajaxRequest1.open("GET" , "/project/getdata.php?request=checkorders&id="+id+"&from="+from+"&to="+to, true);
            //ajaxRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            //xmlhttp.setRequestHeader("X-CSRFToken",'dMTISkUIa4DOT7M3zM2SKpuYlHAtDnYo');
            
            ajaxRequest1.send();
        



        ajaxRequest1.onreadystatechange = function(){
            if (ajaxRequest1.readyState === 4 && ajaxRequest1.status === 200) {
                //alert(ajaxRequest1.responseText);
                

                allOrders = JSON.parse(ajaxRequest1.responseText);

                items  = document.querySelectorAll(".unit2");
            
                for(i=0;i<items.length;i++)
                {
                   var aux = items[i].parentNode;
                  aux.removeChild(items[i]);
                }

                
                display  = document.querySelector("#display2");



                for(i=0;allOrders.length;i++)
                {

                    

                    display.innerHTML += "<tr class='unit2'><td><button type='button' onclick='orderItems("+allOrders[i].order_id+",this)' class='btn btn-success btn-xs plus2' >+</button>  "+allOrders[i].date+"</td><td>"+allOrders[i].total_price+" EGP</td></tr>";
                }                
            }
        };

        }

        var exampleSocket = new WebSocket("ws://127.0.0.1:8080");

        exampleSocket.onopen = function (event) {
         // exampleSocket.send("Here's some text that the server is urgently awaiting!"); 
        }

        exampleSocket.onmessage = function (event) {
          message = JSON.parse(event.data);
          alert(event.data);
        }

        function cancel(id)
        {
            wanted = document.querySelector('#a'+id);
            if(wanted==null)return;
            //alert(wanted.innerHTML);
            var message = {
                cmd:"cancel"
                ,
                order_id:id
            };
            exampleSocket.send(JSON.stringify(message));
            zorar = wanted.querySelector('.zorar');
            zorar.innerHTML="";
            state = wanted.querySelector('.order-status');
            state.innerHTML = "canceled";
        }

        function change(id)
        {

            wanted = document.querySelector('#a'+id);
            if(wanted==null)return;
            zorar = wanted.querySelector('.zorar');
            zorar.innerHTML="<button type='button' onclick='delivered("+id+")' class='btn btn-success btn-lg'>Delivered</button>";
            state = wanted.querySelector('.order-status');
            state.innerHTML = "out for delivery";
        }

        function delivered(id)
        {
            wanted = document.querySelector('#a'+id);
            if(wanted==null)return;
            //alert(wanted.innerHTML);
            var message = {
                cmd:"delivered"
                ,
                order_id:id
            };
            exampleSocket.send(JSON.stringify(message));
            zorar = wanted.querySelector('.zorar');
            zorar.innerHTML="";
            state = wanted.querySelector('.order-status');
            state.innerHTML = "done";
        }

        function orderItems(id,button)
        {


            if(button.innerHTML=='+')
            {

                dashes = document.querySelectorAll('.dash2');
                for(i=0;i<dashes.length;i++)
                {
                    dashes[i].innerHTML = '+';
                    dashes[i].className = 'btn btn-success btn-xs plus2';
                }

                //alert("sa7");
                button.innerHTML='-';
                button.className = 'btn btn-danger btn-xs dash2';
                document.querySelector("#multiproducts").style.display = "block";
            }
            else
            {
                button.innerHTML='+';
                button.className = 'btn btn-success btn-xs plus2';
                disp = document.querySelector('#el-data');
                document.querySelector("#multiproducts").style.display = "none";

                disp.innerHTML ="";

                return;
            }
            
            if(window.XMLHttpRequest) {
                ajaxRequest1 = new XMLHttpRequest();
            }
            else {
                ajaxRequest1 = new ActiveXObject("Microsoft.XMLHTTP");
            }

            //if(flag == 1)
            //{
                
            //}
            
            ajaxRequest1.open("GET" , "/project/getdata.php?request=orderitems&id="+id, true);
            //ajaxRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            //xmlhttp.setRequestHeader("X-CSRFToken",'dMTISkUIa4DOT7M3zM2SKpuYlHAtDnYo');
            
            ajaxRequest1.send();
        



        ajaxRequest1.onreadystatechange = function(){
            if (ajaxRequest1.readyState === 4 && ajaxRequest1.status === 200) {
                //alert(ajaxRequest1.responseText);
                allProducts = JSON.parse(ajaxRequest1.responseText);

                disp = document.querySelector('#el-data');

                disp.innerHTML ="";

                for (i=0;i<allProducts.length;i++) {
                    

                    disp.innerHTML +="<div class='col-xs-4 col-sm-4 col-lg-2 ' ><div class='well  product' style='height:275px;background-color: #FFFFFF;'><h3>"+allProducts[i].product_name+" <span class='badge'>"+allProducts[i].quantity+"</span></h3><img src='/project/images/productimage/"+allProducts[i].product_picture+"' width='100%' height='300px'></div></div>"
                }
                
            }
        };

        }



    </script>
  </body>
<html>