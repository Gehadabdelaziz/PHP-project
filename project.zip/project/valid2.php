
<?php

class connect
{
	private $db;
	private static $_instance;

	public static function getInstance() {
		if(!self::$_instance) { // If no instance then make one
			self::$_instance = new self();
		}
		return self::$_instance;
	}


	private function __construct()
	{
		$this->db = mysqli_connect('localhost','root', 'root', 'cafe_system'); 
	}

	public function getConnection() {
		return $this->db;
	}
}
class validate
{
	public $valid;
	public $errors;
	function __construct()
	{
		$errors = array();
	}

	function required($name)
	{  
	    if(empty($_POST[$name]))
	    {
	    	$this->valid = false;
	    	$this->errors[]= "$name can't be empty"; 	
	    }
	}
	
	function email($name)
	{
	    if(!empty($_POST[$name]))
	    {
	    	if(!preg_match("/^[a-z][a-zA-Z0-9\._\-]+@[a-z\-]+(\.[a-z]{1,3})+$/", $_POST[$name]))
		    {
		    	$this->valid = false;
		    	$this->errors[]= "$name formated incorrectly";
		    }
	    }
	}
	
	function check($name)
	{
	    if(!empty($_POST[$name]))
	    {
	    	if(   $_POST[$name] != $_SESSION["security_code"]    )
		    {
		    	$this->valid = false;
		    	$this->errors[]= "security $name incorrect";
		    }
	    }
	}

	function valid($array)
	{
		$this->valid = true;

		foreach ($array as $key => $value) {
		    $funcs = explode(",",$array[$key]) ;
		    foreach ($funcs as $function){
				call_user_func(array($this,$function), $key);
		    }
		
		}

	}
}
?>



