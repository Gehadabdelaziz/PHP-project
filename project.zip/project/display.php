<?php
  
	 header('Content-Type: application/json');

	 include_once "valid2.php";
  	

  	class product
  	{
  		
  		function __construct($product_id,$product_name,$price,$product_picture,$status,$cat_id)
		{
			$this->product_id = $product_id;
			$this->product_name = $product_name;  
			$this->price = $price;
			$this->product_picture = $product_picture; 
			$this->status = $status; 
			$this->cat_id = $cat_id;  

		}
  	}

  	function getCategoryName($db,$id)
  	{
  		$query = "select * from category where cat_id=$id";
  		$result = mysqli_query($db, $query);
  		$row = mysqli_fetch_assoc($result);
  		return $row['cat_name'];
  	}

	$a = connect::getInstance();
	$db = $a->getConnection();
	$objs = array();
	session_start();
	$query = "select * from product where status ='available'";
	$result = mysqli_query($db, $query);

	
	$num_results =mysqli_num_rows($result);
	for ($i=0; $i <$num_results; $i++) 
	{

		$row = mysqli_fetch_assoc($result);
		//echo $row;
		$usr  = new product($row['product_id'],$row['product_name'],$row['price'],$row['product_picture'],$row['status'],$row['cat_id']);
		$usr->category_name = getCategoryName($db,$row['cat_id']);
		$objs[] = $usr ;
		//$usr->boom = $_GET['val'] ;
		//$usr->boom .= $_SESSION['try'] ;
		//$json_obj = json_encode($usr);
		//echo $json_obj;
		
	}

	//$objs[1]->bom[] = new user(555,444,666);
	//$objs[1]->bom[] = new user(111,222,333);
	echo  json_encode($objs);
?>