<?php require_once('admin_bar.php');
session_start();
if(isset($_SESSION["id"]))
{
	if ($_SESSION['id']==1) {	
	echo "<div class='col-md-offset-9 col-md-4'>";
	$userimage=$_SESSION["pic"];
	echo "<img src='images/userimage/$userimage' width='80' height='80'/>";
	echo "admin ".$_SESSION["name"];
	echo "</div>";
	echo "<div class='col-md-offset-10 col-md-4'>";
	echo "<a href=logout.php >logout</a>";
	echo "</div>";
	}
	else
	{
		echo '<h1 class="text-center" style="margin-top:200px"><font color="#990000">
		Permission Denied</font></h1>';
	
		exit();
	}

}
else
{ 
header("Location: /project/log.php");	
} 
?>
<!DOCTYPE html>

<html>
<div class="container">
<div class="row">
<div class="col-md-offset-4 col-md-3">

<form  enctype="multipart/form-data" action="product_validation.php?flag=1" 
method="POST" class="form-signin">
<strong> Add Product</strong><br>

<div class="form-group">
<label>Product</label> 
<input class="form-control" type="text" name="product_name" 
value="<?php if(!empty($_GET['product_name'])){echo $_GET['product_name'];} ?>" 
placeholder='Enter Product name ...' />
</div>
<?php if(!empty($_GET['Err']))foreach($_GET['Err'] as $err){ if ($err=="product_name is Required"){echo "<font color='#990000'>** Product name is required</font>";}}?>


<div class="form-group">
<label>Price</label>  
<input class="form-control" type="text" name="price" 
value="<?php if(!empty($_GET['price'])){echo $_GET['price'];} ?>" 
placeholder='Enter Product price ...' />
</div>
<?php if(!empty($_GET['Err']))foreach($_GET['Err'] as $err){ if ($err=="price is Required"){echo "<font color='#990000'>** Price is required</font>";}}?>


<div class="form-group">
<label>Category</label>
<select  class="form-control" name="category" id="select" >
</select>
</div>


<button class="btn btn-success btn-sm" type="button" id="add" onclick="show()">Add Category</button>
<div class="form-group">
<input  class="form-control" type="text" id="name" style="display:none;"/>
</div>

<button class="btn btn-success btn-sm" type="button" id="submit" style="display:none;" onclick="ajax()">Add</button>
<div  class="form-group" id="result"></div>
<?php if(!empty($_GET['Err']))foreach($_GET['Err'] as $err){ if ($err=="this category is required"){echo "<font color='#990000'>** Category is required</font>";}}?>





<?php if (!empty($_GET['image'])){echo '<img  style="width:70px;height=70px;" src=images/productimage/'.$_GET['image'].' />';
echo '<input  type="hidden" name="up" value="'.$_GET['up'].'" />';}else{echo '<input  type="hidden" name="up" value="0" >';} ?>

<div class="form-group">
<label for="image">Upload your Image</label>
<input type="hidden" name="image" value="<?php if (!empty($_GET['image'])){echo $_GET['image'];} ?>" />
<input type="file" name="image" id="image"/><?php if (!empty($_GET['imgErr'])){echo "<font color='#990000'>** Image is required</font>";} ?>
</div>


<?php if(!empty($_GET['msg'])) {echo  "<font color='#990000'>".$_GET['msg']."</font>";}?>
<br>
<input class="btn btn-success btn-sm" type="Submit" name="submit" value="Save">
<input class="btn btn-danger btn-sm" type="reset" name="reset" value="Reset"/>

<?php if (isset($_POST['submit'])) {echo $image_error;}?>

</form>


<body onload="combo_ajax()">
<script>
var ajaxRequest;
	function combo_ajax() {//show combox
			    var select=document.getElementById("select");
			    select.innerHTML='';
			    if(window.XMLHttpRequest) {
				ajaxRequest = new XMLHttpRequest();
			    }
			    else {
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			    }
			    ajaxRequest.open("GET" , "/project/product_ajax.php?flag=1", true);
			    ajaxRequest.send();
		

			
			ajaxRequest.onreadystatechange = function(){
			    if (ajaxRequest.readyState === 4 && ajaxRequest.status === 200) {
				   var response = JSON.parse(ajaxRequest.responseText);
					numOptions = response.length;
					for (i = 0; i < numOptions; i++) {
					    anOption = document.createElement('option');
					    anOption.value = response[i].cat_name;
					    anOption.text = response[i].cat_name;
					    select.appendChild(anOption);
					}
			    }
			};


	}
var ajaxRequest2;
var click;
		function ajax() {//add category
				var val= document.getElementById("name").value;
				if(val!="" ){
					    if(window.XMLHttpRequest) {
						ajaxRequest2 = new XMLHttpRequest();
					    }
					    else {
						ajaxRequest2 = new ActiveXObject("Microsoft.XMLHTTP");
					    }
					    // var val= document.getElementById("name").value;
					    ajaxRequest2.open("GET" , "/project/product_ajax.php?flag=2&value="+val, true);
					    ajaxRequest2.send();
		
						

					ajaxRequest2.onreadystatechange = function(){
					    if (ajaxRequest2.readyState === 4 && ajaxRequest2.status === 200) {


							//console.log(ajaxRequest2.responseText);	
						var response = JSON.parse(ajaxRequest2.responseText);
							//alert(response.id);
							if(response.id=="add"){
								
								  document.getElementById("name").value="";
								  document.getElementById("name").style.display="none";
			   					  document.getElementById("submit").style.display="none";
  								document.getElementById("result").style.display="none";
								combo_ajax();
								
							}else{
								document.getElementById("result").innerHTML =response.id;
							}
					    }
					};
				}else{
					document.getElementById("result").innerHTML ="You have to enter value";
				}	

			}

		function show(){
			       document.getElementById("name").style.display="block";
			       document.getElementById("submit").style.display="block";
			}

		
        


</script>
</body>
</div>
</div>

</html>
