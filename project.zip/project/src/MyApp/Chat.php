<?php
namespace MyApp;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;



class connect
{
    private $db;
    private static $_instance;

    public static function getInstance() {
        if(!self::$_instance) { // If no instance then make one
            self::$_instance = new self();
        }
        return self::$_instance;
    }


    private function __construct()
    {
        $this->db = mysqli_connect('localhost','root', 'root', 'cafe_system'); 
    }

    public function getConnection() {
        return $this->db;
    }
}

class product
    {
        
        function __construct($product_id,$product_name,$price,$product_picture,$status,$cat_id)
        {
            $this->product_id = $product_id;
            $this->product_name = $product_name;  
            $this->price = $price;
            $this->product_picture = $product_picture; 
            $this->status = $status; 
            $this->cat_id = $cat_id;  

        }
    }

    function getCategoryName($db,$id)
    {
        $query = "select * from category where cat_id=$id";
        $result = mysqli_query($db, $query);
        $row = mysqli_fetch_assoc($result);
        return $row['cat_name'];
    }

    

class Chat implements MessageComponentInterface {
    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    public function onOpen(ConnectionInterface $conn) {
        // Store the new connection to send messages to later
        $this->clients->attach($conn);

        echo "New connection! ({$conn->resourceId})\n";
        
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $numRecv = count($this->clients) - 1;
        echo sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
            , $from->resourceId, $msg, $numRecv, $numRecv == 1 ? '' : 's');

        $obj = json_decode($msg);



        if($obj->cmd=="order"){
            
            $a = connect::getInstance();
    
            $db = $a->getConnection();

            $notes = $obj->notes;

            $total_price = $obj->total_price;

            mysqli_query($db,"INSERT INTO  orders (order_status ,notes ,total_price ,date ,user_id , room_id ) VALUES ('processing', '$notes',  $total_price ,CURRENT_TIMESTAMP , $obj->user_id , $obj->room );");

            $order_id = $db->insert_id;

            foreach($obj->data as $jsonObject)
            {   
                $quantitiy = $jsonObject->quantitiy;

                $product_id = $jsonObject->product_id;

                mysqli_query($db,"INSERT INTO  order_product (order_id ,product_id ,amount) VALUES ($order_id ,$product_id , $quantitiy);");
            }

            foreach ($this->clients as $client) {
            //echo $obj->user_id;
            // The sender is not the receiver, send to each client connected
            $client->send($msg);
            
            }
        }elseif ($obj->cmd=="cancel") {

            $a = connect::getInstance();
    
            $db = $a->getConnection();

            $order_id = $obj->order_id;

            mysqli_query($db,"UPDATE  orders SET  order_status =  'canceled' WHERE  order_id =$order_id;");
            
            foreach ($this->clients as $client) {
            //echo $obj->user_id;
            // The sender is not the receiver, send to each client connected
            $client->send($msg);
            }

           
        }elseif ($obj->cmd=="delivered") {

            $a = connect::getInstance();
    
            $db = $a->getConnection();

            $order_id = $obj->order_id;

            mysqli_query($db,"UPDATE  orders SET  order_status =  'done' WHERE  order_id =$order_id;");
            
            foreach ($this->clients as $client) {
            //echo $obj->user_id;
            // The sender is not the receiver, send to each client connected
            $client->send($msg);
            }

           
        } elseif ($obj->cmd=="deliver") {

            foreach ($this->clients as $client) {
    
                $client->send($msg);
            }


        }

        elseif ($obj->cmd=="availablility") {

        foreach ($this->clients as $client) {
        //echo $obj->user_id;
        // The sender is not the receiver, send to each client connected
        $client->send($msg);
        }
        }    
    }

    public function onClose(ConnectionInterface $conn) {
        // The connection is closed, remove it, as we can no longer send it messages
        $this->clients->detach($conn);

        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }
}



