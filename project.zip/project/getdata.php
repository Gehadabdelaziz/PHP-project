<?php
  
	 header('Content-Type: application/json');

	class connect
	{
	    private $db;
	    private static $_instance;

	    public static function getInstance() {
	        if(!self::$_instance) { // If no instance then make one
	            self::$_instance = new self();
	        }
	        return self::$_instance;
	    }


	    private function __construct()
	    {
	        $this->db = mysqli_connect('localhost','root', 'root', 'cafe_system'); 
	    }

	    public function getConnection() {
	        return $this->db;
	    }
	}


  	class product
  	{
  		
  		function __construct($product_id,$product_name,$price,$product_picture,$status,$cat_id)
		{
			$this->product_id = $product_id;
			$this->product_name = $product_name;  
			$this->price = $price;
			$this->product_picture = $product_picture; 
			$this->status = $status; 
			$this->cat_id = $cat_id;  

		}
  	}


	class room
  	{
  		function __construct($room_id,$room_no)
		{
			$this->room_id =$room_id;
			$this->room_no =$room_no;
		}
  	}
  	class userInAdminPage
  	{
  		function __construct($user_id,$user_name)
		{
			$this->user_id =$user_id;
			$this->user_name =$user_name;
		}
  	}

  	class order
  	{
  		function __construct($order_id,$date,$order_status,$total_price)
		{
			$this->order_id =$order_id;
			$this->date =$date;
			$this->order_status =$order_status;
			$this->total_price =$total_price;
		}
  	}

  	class check
  	{
  		function __construct($user_id,$total_price)
		{
			$this->user_id =$user_id;
			
			$this->total_price =$total_price;
		}
  	}

  	

  	function getCategoryName($db,$id)
  	{
  		$query = "select * from category where cat_id=$id";
  		$result = mysqli_query($db, $query);
  		$row = mysqli_fetch_assoc($result);
  		return $row['cat_name'];
  	}

  	function getItem($db,$id)
  	{
  		$query = "select * from product where product_id=$id";
  		$result = mysqli_query($db, $query);
  		$row = mysqli_fetch_assoc($result);
  		return new product($row['product_id'],$row['product_name'],$row['price'],$row['product_picture'],$row['status'],$row['cat_id']);
  	}

  	function getName($db,$id)
  	{
  		$query = "select * from users where user_id=$id";
  		$result = mysqli_query($db, $query);
  		$row = mysqli_fetch_assoc($result);
  		return $row['user_name'];
  	}

	$a = connect::getInstance();
	$db = $a->getConnection();

	//mysqli_query($db,"INSERT INTO product (product_name,price,product_picture,status,cat_id) values ('combo',1.1,'http://www.impratea.co.ke/images/tea_cup.png','available',1)");

	//echo $db->insert_id;

	$objs = array();
	
	if($_GET['request']=="room"){
		$query = "select * from room";
		$result = mysqli_query($db, $query);

		
		$num_results =mysqli_num_rows($result);
		for ($i=0; $i <$num_results; $i++) 
		{

			$row = mysqli_fetch_assoc($result);
			$usr  = new room($row['room_id'],$row['room_no']);
			//$usr->category_name = getCategoryName($db,$row['cat_id']);
			$objs[] = $usr ;
			
		}


	}elseif ($_GET['request']=="user") {
		# code...userInAdminPage
		$query = "select * from users";
		$result = mysqli_query($db, $query);

		
		$num_results =mysqli_num_rows($result);
		for ($i=0; $i <$num_results; $i++) 
		{

			$row = mysqli_fetch_assoc($result);
			$usr  = new userInAdminPage($row['user_id'],$row['user_name']);
			//$usr->category_name = getCategoryName($db,$row['cat_id']);
			$objs[] = $usr ;
			
		}
	}elseif ($_GET['request']=="order") {
		# code...userInAdminPage
		$from = $_GET['from'];
		$to = $_GET['to'];
		$id = $_GET['id'];
		$query = "select * from orders WHERE DATE BETWEEN '$from' AND '$to' AND user_id=$id ORDER BY order_id DESC ";		$result = mysqli_query($db, $query);

		
		$num_results =mysqli_num_rows($result);
		for ($i=0; $i <$num_results; $i++) 
		{

			$row = mysqli_fetch_assoc($result);
			$usr  = new order($row['order_id'],$row['date'],$row['order_status'],$row['total_price']);
			//$usr->category_name = getCategoryName($db,$row['cat_id']);$order_id,$date,$order_status,$total_price)
			$objs[] = $usr ;
			
		}
	}
	elseif ($_GET['request']=="orderitems") {
		# code...userInAdminPage
		$id = $_GET['id'];
		
		$query = "select * from order_product WHERE order_id = $id ";
		$result = mysqli_query($db, $query);

		
		$num_results =mysqli_num_rows($result);
		for ($i=0; $i <$num_results; $i++) 
		{
			$row = mysqli_fetch_assoc($result);
			//$usr  = new order($row['order_id'],$row['date'],$row['order_status'],$row['total_price']);
			//$usr->category_name = getCategoryName($db,$row['cat_id']);$order_id,$date,$order_status,$total_price)
			$usr  =  getItem($db,$row['product_id']);
			$usr->quantity = $row['amount'];
			$objs[] = $usr;//$order_id,$date,$order_status,$total_price);
			
		}
	}
	elseif ($_GET['request']=="check") {
		# code...userInAdminPage
		$from = $_GET['from'];
		$to = $_GET['to'];
		$query = "select user_id,SUM( total_price ) AS amount from orders WHERE DATE BETWEEN '$from' AND '$to' GROUP BY user_id ORDER BY order_id DESC ";
		$result = mysqli_query($db, $query);

		
		$num_results =mysqli_num_rows($result);
		for ($i=0; $i <$num_results; $i++) 
		{

			$row = mysqli_fetch_assoc($result);
			$usr  = new check($row['user_id'],$row['amount']);
			$usr->user_name = getName($db,$row['user_id']);//$order_id,$date,$order_status,$total_price)
			$objs[] = $usr ;
			
		}
	}
	elseif ($_GET['request']=="checkorders") {
		# code...userInAdminPage
		$id = $_GET['id'];
		$from = $_GET['from'];
		$to = $_GET['to'];

		//SELECT * FROM orders WHERE DATE BETWEEN  '2015-03-06 13:19:35' AND  '2015-03-07 13:19:35' AND user_id =1

		$query = "select *  from orders WHERE DATE BETWEEN '$from' AND '$to'  AND user_id =$id ORDER BY date DESC ";
		$result = mysqli_query($db, $query);

		
		$num_results =mysqli_num_rows($result);
		for ($i=0; $i <$num_results; $i++) 
		{
			$row = mysqli_fetch_assoc($result);

			$usr  = new order($row['order_id'],$row['date'],$row['order_status'],$row['total_price']);
			//$usr->category_name = getCategoryName($db,$row['cat_id']);$order_id,$date,$order_status,$total_price)
			//$usr  =  getItem($db,$row['product_id']);
			//$usr->quantity = $row['amount'];
			$objs[] = $usr;//$order_id,$date,$order_status,$total_price);
			
		}
	}
	
	echo  json_encode($objs);
?>