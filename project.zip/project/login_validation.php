<?php
function __autoload($classname) {
    $filename =  $classname .".php";
    include_once($filename);
}
if($_POST){
 $flag=$_GET['flag'];

if($flag==0)//login
{
	$rules = array(
	'password'=>'required',
	'mail'=>'required',
	);

}elseif($flag==1){//forgetpassword
	$rules = array(
	'mail'=>'required',
	);

}elseif($flag==2){//forgetpassword
	$rules = array(
	'answer'=>'required',
	);

}elseif($flag==3){//forgetpassword
	$rules = array(
	'password'=>'required',
	);

}
	$validation=new Validation();
	if($validation->validate($_POST,$rules))  //check validation 
	{
		//check if user in database
			$db = ORM::getInstance();
			$db->setTable('users');
			if($flag==0){//login
				$mysqli = $db->select("*",array('email'=>$_POST['mail'],'password'=>$_POST['password'])); 
				if($mysqli!=NULL) //if user in database
				{
					session_start();
					$_SESSION["id"] = $mysqli->{'user_id'};
					$_SESSION["name"] =$mysqli->{'user_name'};
					$_SESSION["pic"] = $mysqli->{'profile_picture'};

					if($mysqli->{'user_id'}==1)
						{header("Location: /project/homeadmin.php");
					}else{
						header("Location: /project/process.php");
					}
					}
					else
					{ //user not in database
						$error="<br> Sorry Wrong Email or Password";
						header("Location: /project/log.php?Err[0]=$error");
					}

			}elseif($flag==1){//forgetpassword(get question)

					$mysqli = $db->select("*",array('email'=>$_POST['mail'])); 
					if($mysqli!=NULL) //if user in database
					  {
						$ques = $mysqli->{'question'};
						$mail =$mysqli->{'email'};
						header("Location: /project/forgetpassword.php/?ques=".$ques."&mail=".$mail);
					   }
					   else
					   { //user not in database
						$error="<br> Sorry Wrong Email";
						header("Location: /project/forgetpassword.php?ques=no_ques&Err[0]=$error");
					  
			       		  }


			}elseif($flag==2){//forgetpassword(check answer )
$mysqli = $db->select("*",array('email'=>$_POST['mail'])); 
					if($mysqli!=NULL) //if user in database
					  {
						if( $mysqli->{'answer'}==$_POST['answer']){//if answer was right
							session_start();
							$_SESSION["id"] = $mysqli->{'user_id'};
							$_SESSION["name"] =$mysqli->{'user_name'};
							$_SESSION["pic"] = $mysqli->{'profile_picture'};
							header("Location: /project/editpassword.php");
						}else{//if answer was wrong
							$error="<br> Wrong answer ";
							$ques = $mysqli->{'question'};
							$mail =$mysqli->{'email'};
							header("Location: /project/forgetpassword.php?ques=".$ques."&mail=".$mail."&Err[0]=$error");
						}
					   }else{ //user not in database
						$error="<br> This Email didn't regist before";
						header("Location: /project/forgetpassword.php?ques=no_ques&Err[0]=$error");
					  
			       		  }


			}elseif($flag==3){//editpassword
			        session_start();//must be there
				if($_POST['password']==$_POST['confirm_password']){//confirm password
						if($_SESSION['id']==1)//if user is admin
							{header("Location: /project/homeadmin.php");
						}else{//if user is normal user
							header("Location: /project/process.php");	
						}
				}else{//two password doesn't match
					$error="<br> Two password doesn't match ";
					header("Location: /project/editpassword.php?Err[0]=$error");
				}
			}

	}else{  // if data not valid
		
		$err=$validation->errors; 
		$error="";
			 for($i=0 ; $i<count($err) ; $i++){
				 $error=$error."&Err[$i]=".$err[$i]; 
			}
		if($flag==0)//invalid message for login
		{
			header("Location: /project/log.php?Err=$error");
		}elseif($flag==1){//invalid message for forgetpassword
			header("Location: /project/forgetpassword.php?ques=no_ques&Err=$error");
		}elseif($flag==2){//invalid message for answer of forgetpassword
			header("Location: /project/forgetpassword.php?ques=".$_POST['ques']."&mail=".$_POST['mail']."$error");
		}elseif($flag==3){//invalid message for editpassword
			header("Location: /project/editpassword.php?$error");
		}
	}
}
?>


