<?php require_once('admin_bar.php');
session_start();
if(isset($_SESSION["id"]))
{
	if ($_SESSION['id']==1) {	
	echo "<div class='col-md-offset-9 col-md-4'>";
	$userimage=$_SESSION["pic"];
	echo "<img src='images/userimage/$userimage' width='80' height='80'/>";
	echo "admin ".$_SESSION["name"];
	echo "</div>";
	echo "<div class='col-md-offset-10 col-md-4'>";
	echo "<a href=logout.php >logout</a>";
	echo "</div>";
	}
	else
	{
		echo '<h1 class="text-center" style="margin-top:200px"><font color="#990000">
		Permission Denied</font></h1>';
	
		exit();
	}

}
else
{ 
header("Location: /project/log.php");	
} 

function __autoload($classname) {
	$filename =  $classname .".php";
	include_once($filename);
	}
$obj = ORM::getInstance();

if ($_POST) {	
		if (isset($_POST['submit'])) {
		$upfile = "/var/www/html/project/images/userimage/".$_FILES['image']['name'] ;
		$image_name=$_FILES['image']['name'];
		$image_path="/var/www/html/project/images/userimage/".$image_name;
		$image_error="";
		if ($_FILES['image']['error'] > 0)
		{
			switch ($_FILES['image']['error'])
			{
			case 1: $image_error='* Image exceeded upload_max_filesize';
			break;
			case 2: $image_error='* Image exceeded max_file_size';
			break;
			case 3: $image_error='* Image only partially uploaded';
			break;
			case 4: if($_POST['image']!=""){
				$image_name=$_POST['image']; 
			}else
			{
				$image_error='* No image uploaded';
			}
			
			break;
			case 6: $image_error='* Cannot upload image: No temp directory specified';
			break;
			case 7: $image_error='* Upload failed: Cannot write to disk';
			break;
			}
			
		}
		else{
			if ($_FILES['image']['type']!='image/jpeg')
			{
				$image_error='* image is not jpeg';
				
			}
			if (is_uploaded_file($_FILES['image']['tmp_name']))
			{
				if (!move_uploaded_file($_FILES['image']['tmp_name'], $upfile))
				{
					$image_error='* Could not move image to destination directory';
				}
				else
				{
					if($_FILES['image']){
						$image_name=$_FILES['image']['name'];
					 }elseif($_POST['image']){
						$image_name=$_POST['image']; 
					 }else{$image_error='* No image uploaded';}
				  }
			}
			else
			{
				if($_FILES['image']){
					$image_name=$_FILES['image']['name'];
				 }elseif($_POST['image']){
					$image_name=$_POST['image']; 
				 }else{$image_error='* No image uploaded';}
				
			}
		}
	
}

if (empty($_POST['email_edit'])) {

	$email_rule='required|email|unique';
}
else
{
	$email_rule='required|email';
}
	
	$rules=array(
		'name'=>'required',
		'email'=>$email_rule,
		'password'=>'required',
		'confirm_password'=>'required|password',
		'Room_No'=>'required',
		'Ext'=>'required',
		'question'=>'required',
		'answer'=>'required',

		);
	$validation=new Validation();
	if (empty($_POST['email_edit'])) {
		if ($validation->validate($_POST,$rules)) 
		{ 
			if ($image_error=="") {	
			
			//insert room_no or get room_id if the number exists
				
				$obj->setTable('room');
				$room_selected=$obj->select('room_id',array('room_no'=>$_POST['Room_No']));

				if (!$room_selected) {//if room not found insert it and reterive id 
					$obj->insert(array('room_no'=>$_POST['Room_No']));
					$room_selected=$obj->select('room_id',array('room_no'=>$_POST['Room_No']));
				}
					$obj->setTable('users');
					$obj->insert(array('user_name'=>$_POST['name'],'email'=>$_POST['email'],
						'password'=>$_POST['password'],'ext'=>$_POST['Ext'],'question'=>$_POST['question']
						,'answer'=>$_POST['answer'],'profile_picture'=>$image_name,'room_id'=>$room_selected));
			}

		}
		header("Location: allusers.php");
	}
	else
		{	
			if ($validation->validate($_POST,$rules)) 
			{ 
			if ($image_error=="") {
			
			$obj->setTable('room');
			$room_selected=$obj->select('room_id',array('room_no'=>$_POST['Room_No'])); 
			if (!$room_selected) {//if room not found insert it and reterive id 
			$obj->insert(array('room_no'=>$_POST['Room_No']));
			$room_selected=$obj->select('room_id',array('room_no'=>$_POST['Room_No']));
			}			
			$obj->setTable('users');
			echo $obj->update(array('user_name'=>$_POST['name'],'email'=>$_POST['email'],
				'password'=>$_POST['password'],'ext'=>$_POST['Ext'],'question'=>$_POST['question']
				,'answer'=>$_POST['answer'],'profile_picture'=>$image_name,'room_id'=>$room_selected),
				array('email'=>$_POST['email']));
		}
		header("Location: allusers.php");	
	}
	else{
		$edit=$_POST['email_edit'];
		header("Location: adduser.php?email_edit=$edit");
	}
		
	}
	
	$validate_result=$validation->errors;
	
	function error ($fieldname,$validate_result){	
		$return="";
			foreach ($validate_result as $error) {
				$field=explode(" ",$error);
				$field_name=$field[0];
				if ($field_name==$fieldname) {
					$return="* "."$error";
					break;
				}
			}	
		return $return;
	}

}
//=====================================================================//
//form for edit user information
if (!empty($_GET)) {
	$obj->setTable('users');
	if (isset($_GET["email_edit"])) {
		$user_to_edit=$obj->select('*',array('email'=>$_GET['email_edit']));

	}
}


//====================================================================//



?>

<html>

	<body>
	<div class="container">
	<div class="row">
	<div class="col-md-offset-4 col-md-3">
  		<form method="POST" action="adduser.php" enctype="multipart/form-data" class="form-signin">
  		
  		<input type="hidden" name="email_edit" value="<?php 
  		if (isset($_GET["email_edit"])) echo $_GET['email_edit']?>">
  			<strong>Add User</strong><br>

  			<div class="form-group">
			<label>Name</label><br>
			<input class="form-control" type="text" name="name" value="<?php 
			if (isset($_POST['submit'])) 
			{echo $_POST["name"];}
			if (isset($_GET["email_edit"])) {
			 	echo $user_to_edit->user_name;
			 } 
			
			?>" 
			placeholder='Enter Your name ...'/>
			<?php if (isset($_POST['submit'])) {
				echo error("name",$validate_result);
				}?>
			</div>

			<div class="form-group">
			<label>Email</label><br>
			<input class="form-control" type="text" name="email" value="<?php if (isset($_POST['submit'])) 
			{echo $_POST["email"];} 
			if (isset($_GET["email_edit"])) {
			 	echo $user_to_edit->email; 
			 	}?>" <?php if (isset($_GET["email_edit"])){?> readonly <?php }?>
			 	placeholder='Enter Your email ...'/>
			<?php if (isset($_POST['submit'])) {
				echo error("email",$validate_result);
				}?>
			</div>

			<div class="form-group">
			<label>Passowrd</label><br>
			<input class="form-control" type="password" name="password" value="<?php
			if (isset($_GET["email_edit"])) {
			 	echo $user_to_edit->password;
			 } 
			?>"placeholder='Enter Your password...'/>
			<?php if (isset($_POST['submit'])) {
				echo error("password",$validate_result);
				}?>
			</div>

			<div class="form-group">
			<label>Confirm Passowrd</label><br>
			<input class="form-control" type="password" name="confirm_password" value="<?php
			if (isset($_GET["email_edit"])) {
			 	echo $user_to_edit->password;
			 } 
			?>"placeholder='re-enter Your password...'/>
			<?php if (isset($_POST['submit'])) {
				echo error("confirm_password",$validate_result);
				}?>
			</div>

			<div class="form-group">
			<label>Room No.</label><br>
			<input class="form-control" type="text" name="Room_No" value="<?php if (isset($_POST['submit'])) 
			echo $_POST["Room_No"]; 
			if (isset($_GET["email_edit"])) {
				
				$obj->setTable('room');
				$room_selected=$obj->select('room_no',array('room_id'=>$user_to_edit->room_id));
			 	echo $room_selected;
			 } 
			?>" placeholder='Enter Your room_number...'/>
			<?php if (isset($_POST['submit'])) {
				echo error("Room_No",$validate_result);
				}?> 
			</div>


			<div class="form-group">
			<label>Ext.</label><br>
			<input class="form-control" type="text" name="Ext" value="<?php if (isset($_POST['submit'])) 
			echo $_POST["Ext"]; 
			if (isset($_GET["email_edit"])) {
			 	echo $user_to_edit->ext;
			 } 
			?>" placeholder='Enter Your Ext...'/>
			<?php if (isset($_POST['submit'])) {
				echo error("Ext",$validate_result);
				}?>
			</div> 

			<div class="form-group">
			<label>Question</label><br>
			<textarea class="form-control" rows="1" cols="31" name="question"><?php if (isset($_POST['submit'])) 
			echo $_POST["question"]; ?><?php
			 if (isset($_GET["email_edit"])) {
			 	echo $user_to_edit->question;
			 } ?> </textarea>
			<?php if (isset($_POST['submit'])) {
				echo error("question",$validate_result);
				}?>
			</div>

			<div class="form-group">
			<label>Answer</label> <br>
			<textarea class="form-control" rows="1" cols="31" name="answer"><?php if (isset($_POST['submit'])) 
			echo $_POST["answer"]; ?><?php 
			if (isset($_GET["email_edit"])) {
			 	echo $user_to_edit->answer;
			 } ?></textarea>
			<?php if (isset($_POST['submit'])) {
				echo error("answer",$validate_result);
				}?>
			</div>

			<div class="form-group">
			<label>Profile picture</label><br>
			<input  type="file" name="image" id="image"><?php if (isset($_POST['submit'])) {
				echo $image_error;
			}?>
			<input type="hidden" name="image" 
			value="<?php if (isset($_GET["email_edit"])) {echo $user_to_edit->profile_picture;}?>" />
			</div>
			<br>
			<input class="btn btn-success btn-sm" type="submit" name="submit" value="Save"/>
			<input class="btn btn-danger btn-sm" type="reset" name="reset" value="Reset"/>
		</form>
		</div>
		</div>
		</div>
</body>
</html>




