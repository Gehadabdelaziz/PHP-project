<?php
header('Content-Type: application/json');

function __autoload($classname) {
    $filename =  $classname .".php";
    include_once($filename);
}


$db = ORM::getInstance();
$db->setTable('category');
$flag=$_GET['flag'];
$where_condition="null";

if($flag==1){//get value to put it in combobox
		  	class cat
		  	{
		  		public $cat_name;
		  		function __construct($cat_name)
				{
					$this->cat_name = $cat_name;

				}
		  	}

		$mysqli = $db->selectall($where_condition);
			$objs = array();
			$num_results =mysqli_num_rows($mysqli);

			for ($i=0; $i <$num_results; $i++) 
			{

				$row = mysqli_fetch_assoc($mysqli);
				$cat  = new cat($row['cat_name']);
				$objs[] = $cat ;
	
			}

		echo  json_encode($objs);

}elseif($flag==2){//add category

		$data=$_GET['value'];
		$mysqli = $db->selectall($where_condition);
		$num_results =mysqli_num_rows( $mysqli);
		$check=0;
		if ($num_results > 0) {
		     while($row = mysqli_fetch_assoc($mysqli)) {//check if category is exit
				if($data==$row["cat_name"]){
					$check=1;
				}
			}//end while

				if($check==1){	
					echo '{"id":"This Category is already exist"}';	
				}else{
					$mysqli = $db->insert(array('cat_name'=>$data));
					//echo "add";
					   echo '{"id":"add"}';
			
				}		
		   
		}else {
		    		$mysqli = $db->insert(array('cat_name'=>$data));
				 echo '{"id":"add"}';
		}

}
?>
