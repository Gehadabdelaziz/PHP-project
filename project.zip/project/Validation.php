<?php
	/**
	* 
	*/
	class Validation 
	{
		public $errors=array();

		public function validate($data,$rules)
		{
			$valid=true;
			foreach ($rules as $fieldname=> $rule) {
				$callbacks=explode("|",$rule);
				foreach ($callbacks as $callback) {
					if (isset($data[$fieldname]))
					{
						$value=$data[$fieldname];
						if ($fieldname=="password") {
							$password=$value;
						}
					}
					else
					{
						$value=NULL;
					}
					if ($callback=="password") {
						if(!$this->$callback($value,$fieldname,$password))
						{
							$valid=false;
						}
					}
					else{
						if(!$this->$callback($value,$fieldname))
						{
							$valid=false;
						}
					}


				}
			}
			return $valid;

		}
		protected function required($value,$fieldname)
		{
			$valid=!empty($value);
			if (!$valid) {
				$this->errors[]="$fieldname is Required";
			}
			return $valid;
		}

		protected function email($value,$fieldname)
		{
			$my_regex="/^[a-zA-Z][a-zA-Z0-9._-]+\@[a-zA-Z]+\.([a-zA-Z]{2,4}|[a-zA-Z]{2,4}\.[a-zA-Z]{2})$/";
			$valid=preg_match($my_regex,$value);
			if (!$valid) {
				$this->errors[]="$fieldname is Invalid";
			}
			return $valid;
		}

		protected function unique($value,$fieldname)
		{
			$valid=true;
			$obj = ORM::getInstance();
			$obj->setTable('users');
			$user_selected=$obj->select('email',array('email'=>$value));
			if ($user_selected) {
				$this->errors[]="$fieldname is already exists";
				$valid=false;
			}
			return $valid;
		}

		protected function password($value,$fieldname,$password)
		{
			$valid =true;
			if ($value!=$password) {
				$this->errors[]="$fieldname doesn't match";
				$valid=false;
			}
			return $valid;
		}
	}
?>